#!/usr/bin/env bash
# LinVClipBoard — weekly update checker (invoked by the systemd user timer).
#
# Compares the installed daemon version with the latest GitHub release and
# sends a desktop notification if a newer one exists. Notify-only: installing
# updates is the package manager's job (`apt upgrade`, `dnf upgrade`, or the
# one-line installer).

set -euo pipefail

REPO="DreamerX00/LinVClipBoard"
API="https://api.github.com/repos/${REPO}/releases/latest"

installed_version() {
    # `clipd --version` prints "clipd X.Y.Z" — same package as the GUI.
    if command -v clipd >/dev/null 2>&1; then
        timeout 5 clipd --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 && return 0
    fi
    if command -v dpkg-query >/dev/null 2>&1; then
        dpkg-query -W -f='${Version}' linvclipboard 2>/dev/null | sed -E 's/^([0-9.]+).*/\1/' && return 0
    fi
    if command -v rpm >/dev/null 2>&1; then
        rpm -q --qf '%{VERSION}' linvclipboard 2>/dev/null && return 0
    fi
    echo "0.0.0"
}

CURRENT=$(installed_version)
[ -n "$CURRENT" ] || CURRENT="0.0.0"

LATEST=$(curl -fsSL --max-time 20 -H "Accept: application/vnd.github+json" "$API" 2>/dev/null \
    | grep -oE '"tag_name"[[:space:]]*:[[:space:]]*"v?[^"]+"' \
    | sed -E 's/.*"v?([^"]+)"$/\1/' || true)

[ -n "$LATEST" ] || exit 0   # network failed — silently skip

# Numeric dotted-version compare: returns 0 if $1 > $2.
ver_gt() {
    local IFS=.
    # shellcheck disable=SC2206
    local a=($1) b=($2) i
    for ((i = 0; i < ${#a[@]} || i < ${#b[@]}; i++)); do
        local x=${a[i]:-0} y=${b[i]:-0}
        ((x > y)) && return 0
        ((x < y)) && return 1
    done
    return 1
}

if ver_gt "$LATEST" "$CURRENT"; then
    notify-send -a LinVClipBoard -i linvclipboard \
        "LinVClipBoard ${LATEST} is available" \
        "You have ${CURRENT}. Update with your package manager or run the installer again:
https://github.com/${REPO}/releases/latest" 2>/dev/null || true
fi
