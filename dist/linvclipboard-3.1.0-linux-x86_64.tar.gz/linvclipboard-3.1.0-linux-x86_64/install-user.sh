#!/usr/bin/env bash
# Install LinVClipBoard from the release tarball into the current user's home
# (no root). Run from inside the extracted tarball directory:
#
#   ./install-user.sh [--prefix ~/.local] [--no-start] [--uninstall]
#
# Files go to $PREFIX/bin, $XDG_CONFIG_HOME/systemd/user, $XDG_DATA_HOME/…
# and ~/.config/autostart. The daemon is enabled as a systemd user service.
set -euo pipefail

PREFIX="${HOME}/.local"
START=1
UNINSTALL=0
while [ $# -gt 0 ]; do
    case "$1" in
        --prefix) PREFIX="$2"; shift 2 ;;
        --no-start) START=0; shift ;;
        --uninstall) UNINSTALL=1; shift ;;
        -h|--help) sed -n '2,9p' "$0"; exit 0 ;;
        *) echo "unknown argument: $1" >&2; exit 1 ;;
    esac
done

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
UNIT_DIR="${CONFIG_HOME}/systemd/user"

log() { printf '\033[1;34m==>\033[0m %s\n' "$*"; }

have_systemd_user() { command -v systemctl >/dev/null 2>&1 && systemctl --user show-environment >/dev/null 2>&1; }

if [ "$UNINSTALL" = 1 ]; then
    log "Removing LinVClipBoard from ${PREFIX}"
    if have_systemd_user; then
        systemctl --user disable --now clipd.service linvclip-update-check.timer >/dev/null 2>&1 || true
    fi
    pkill -x linvclip-ui 2>/dev/null || true
    rm -f "${PREFIX}/bin/clipd" "${PREFIX}/bin/clipctl" "${PREFIX}/bin/linvclip-ui"
    rm -f "${UNIT_DIR}/clipd.service" "${UNIT_DIR}/linvclip-update-check.service" "${UNIT_DIR}/linvclip-update-check.timer"
    rm -rf "${PREFIX}/libexec/linvclipboard"
    rm -f "${DATA_HOME}/applications/linvclipboard.desktop" "${CONFIG_HOME}/autostart/linvclipboard.desktop"
    find "${DATA_HOME}/icons/hicolor" -name 'linvclipboard.*' -delete 2>/dev/null || true
    rm -f "${DATA_HOME}/man/man1/clipd.1.gz" "${DATA_HOME}/man/man1/clipctl.1.gz" "${DATA_HOME}/man/man1/linvclip-ui.1.gz"
    rm -f "${DATA_HOME}/bash-completion/completions/clipctl" "${DATA_HOME}/zsh/site-functions/_clipctl" \
          "${CONFIG_HOME}/fish/completions/clipctl.fish"
    have_systemd_user && systemctl --user daemon-reload || true
    log "Done. Your history in ${DATA_HOME}/linvclip was kept; delete it manually if you want."
    exit 0
fi

log "Installing LinVClipBoard into ${PREFIX}"
install -Dm755 "${SRC}/bin/clipd"       "${PREFIX}/bin/clipd"
install -Dm755 "${SRC}/bin/clipctl"     "${PREFIX}/bin/clipctl"
install -Dm755 "${SRC}/bin/linvclip-ui" "${PREFIX}/bin/linvclip-ui"
install -Dm755 "${SRC}/libexec/linvclipboard/update-check.sh" "${PREFIX}/libexec/linvclipboard/update-check.sh"

# Units: rewrite /usr paths to the chosen prefix.
mkdir -p "$UNIT_DIR"
for unit in clipd.service linvclip-update-check.service linvclip-update-check.timer; do
    sed -e "s#/usr/bin/clipd#${PREFIX}/bin/clipd#g" \
        -e "s#/usr/libexec/linvclipboard#${PREFIX}/libexec/linvclipboard#g" \
        "${SRC}/lib/systemd/user/${unit}" > "${UNIT_DIR}/${unit}"
done
# ProtectSystem=strict makes $PREFIX read-only, which is fine (we only exec from it).

mkdir -p "${DATA_HOME}/applications" "${CONFIG_HOME}/autostart"
sed "s#^Exec=linvclip-ui#Exec=${PREFIX}/bin/linvclip-ui#" "${SRC}/share/applications/linvclipboard.desktop" \
    > "${DATA_HOME}/applications/linvclipboard.desktop"
sed "s#^Exec=linvclip-ui#Exec=${PREFIX}/bin/linvclip-ui#" "${SRC}/share/autostart/linvclipboard.desktop" \
    > "${CONFIG_HOME}/autostart/linvclipboard.desktop"

for f in "${SRC}"/share/icons/hicolor/*/apps/linvclipboard.*; do
    rel="${f#"${SRC}"/share/}"
    install -Dm644 "$f" "${DATA_HOME}/${rel}"
done
for f in "${SRC}"/share/man/man1/*.gz; do
    install -Dm644 "$f" "${DATA_HOME}/man/man1/$(basename "$f")"
done
install -Dm644 "${SRC}/share/bash-completion/completions/clipctl" "${DATA_HOME}/bash-completion/completions/clipctl"
install -Dm644 "${SRC}/share/zsh/site-functions/_clipctl"          "${DATA_HOME}/zsh/site-functions/_clipctl"
install -Dm644 "${SRC}/share/fish/vendor_completions.d/clipctl.fish" "${CONFIG_HOME}/fish/completions/clipctl.fish"

command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "${DATA_HOME}/applications" 2>/dev/null || true
command -v gtk-update-icon-cache  >/dev/null 2>&1 && gtk-update-icon-cache -f -t "${DATA_HOME}/icons/hicolor" 2>/dev/null || true

if have_systemd_user; then
    systemctl --user daemon-reload
    systemctl --user enable clipd.service linvclip-update-check.timer >/dev/null
    if [ "$START" = 1 ]; then
        systemctl --user restart clipd.service
        systemctl --user start linvclip-update-check.timer || true
        log "clipd is running (systemctl --user status clipd)"
    fi
else
    log "systemd user session not detected. Start the daemon with: ${PREFIX}/bin/clipd &"
fi

if [ "$START" = 1 ] && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
    if ! pgrep -x linvclip-ui >/dev/null 2>&1; then
        (setsid nohup "${PREFIX}/bin/linvclip-ui" --show >/dev/null 2>&1 &)
    fi
fi

case ":${PATH}:" in
    *":${PREFIX}/bin:"*) ;;
    *) log "Note: ${PREFIX}/bin is not in your PATH; add it to use clipctl from a shell." ;;
esac
log "Installed. Press Ctrl+/ to open the overlay."
