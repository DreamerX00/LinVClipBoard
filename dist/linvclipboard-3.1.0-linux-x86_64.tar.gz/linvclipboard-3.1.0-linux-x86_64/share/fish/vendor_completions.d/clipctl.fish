# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_clipctl_global_optspecs
    string join \n json h/help V/version
end

function __fish_clipctl_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_clipctl_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_clipctl_using_subcommand
    set -l cmd (__fish_clipctl_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c clipctl -n "__fish_clipctl_needs_command" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_needs_command" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_needs_command" -s V -l version -d 'Print version'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "list" -d 'List clipboard history'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "search" -d 'Full-text search of clipboard history'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "regex" -d 'Regular-expression search of clipboard history'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "get" -d 'Show one item in full (accepts a unique ID prefix)'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "cat" -d 'Print an item\'s raw content to stdout (for piping)'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "paste" -d 'Put an item back on the system clipboard (accepts a unique ID prefix)'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "pin" -d 'Toggle pin on an item'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "delete" -d 'Delete an item'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "tag" -d 'Add a tag to an item'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "untag" -d 'Remove a tag from an item'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "clear" -d 'Clear all non-pinned items'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "status" -d 'Show daemon status'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "config" -d 'Show or change configuration'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "snippets" -d 'Snippets / templates'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "doctor" -d 'Diagnose the installation (paths, session, daemon reachability)'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "completions" -d 'Generate shell completions'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "manpage" -d 'Generate man pages'
complete -c clipctl -n "__fish_clipctl_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c clipctl -n "__fish_clipctl_using_subcommand list" -s l -l limit -d 'Maximum number of items to show' -r
complete -c clipctl -n "__fish_clipctl_using_subcommand list" -s o -l offset -d 'Offset for pagination' -r
complete -c clipctl -n "__fish_clipctl_using_subcommand list" -l full-ids -d 'Show full item IDs instead of the 8-character prefix'
complete -c clipctl -n "__fish_clipctl_using_subcommand list" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand list" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand search" -s l -l limit -r
complete -c clipctl -n "__fish_clipctl_using_subcommand search" -s o -l offset -r
complete -c clipctl -n "__fish_clipctl_using_subcommand search" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand search" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand regex" -s l -l limit -r
complete -c clipctl -n "__fish_clipctl_using_subcommand regex" -s o -l offset -r
complete -c clipctl -n "__fish_clipctl_using_subcommand regex" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand regex" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand get" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand get" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand cat" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand cat" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand paste" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand paste" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand pin" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand pin" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand delete" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand delete" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand tag" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand tag" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand untag" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand untag" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand clear" -s y -l yes -d 'Do not ask for confirmation'
complete -c clipctl -n "__fish_clipctl_using_subcommand clear" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand clear" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand status" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand status" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and not __fish_seen_subcommand_from show path reload incognito help" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and not __fish_seen_subcommand_from show path reload incognito help" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and not __fish_seen_subcommand_from show path reload incognito help" -f -a "show" -d 'Print the live daemon configuration (TOML)'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and not __fish_seen_subcommand_from show path reload incognito help" -f -a "path" -d 'Print the config file path'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and not __fish_seen_subcommand_from show path reload incognito help" -f -a "reload" -d 'Ask the daemon to re-read config.toml'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and not __fish_seen_subcommand_from show path reload incognito help" -f -a "incognito" -d 'Pause or resume capture: `clipctl config incognito on|off`'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and not __fish_seen_subcommand_from show path reload incognito help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from show" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from path" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from path" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from reload" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from reload" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from incognito" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from incognito" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "show" -d 'Print the live daemon configuration (TOML)'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "path" -d 'Print the config file path'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "reload" -d 'Ask the daemon to re-read config.toml'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "incognito" -d 'Pause or resume capture: `clipctl config incognito on|off`'
complete -c clipctl -n "__fish_clipctl_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c clipctl -n "__fish_clipctl_using_subcommand snippets" -s f -l folder -d 'Filter by folder' -r
complete -c clipctl -n "__fish_clipctl_using_subcommand snippets" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand snippets" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand doctor" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand doctor" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand completions" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand completions" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand manpage" -l json -d 'Print raw JSON instead of formatted output'
complete -c clipctl -n "__fish_clipctl_using_subcommand manpage" -s h -l help -d 'Print help'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "list" -d 'List clipboard history'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "search" -d 'Full-text search of clipboard history'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "regex" -d 'Regular-expression search of clipboard history'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "get" -d 'Show one item in full (accepts a unique ID prefix)'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "cat" -d 'Print an item\'s raw content to stdout (for piping)'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "paste" -d 'Put an item back on the system clipboard (accepts a unique ID prefix)'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "pin" -d 'Toggle pin on an item'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "delete" -d 'Delete an item'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "tag" -d 'Add a tag to an item'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "untag" -d 'Remove a tag from an item'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "clear" -d 'Clear all non-pinned items'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "status" -d 'Show daemon status'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "config" -d 'Show or change configuration'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "snippets" -d 'Snippets / templates'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "doctor" -d 'Diagnose the installation (paths, session, daemon reachability)'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "completions" -d 'Generate shell completions'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "manpage" -d 'Generate man pages'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and not __fish_seen_subcommand_from list search regex get cat paste pin delete tag untag clear status config snippets doctor completions manpage help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "show" -d 'Print the live daemon configuration (TOML)'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "path" -d 'Print the config file path'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "reload" -d 'Ask the daemon to re-read config.toml'
complete -c clipctl -n "__fish_clipctl_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "incognito" -d 'Pause or resume capture: `clipctl config incognito on|off`'
