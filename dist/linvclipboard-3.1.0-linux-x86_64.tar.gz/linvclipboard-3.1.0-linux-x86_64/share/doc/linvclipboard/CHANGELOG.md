# Changelog

All notable changes to LinVClipBoard are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses
[Semantic Versioning](https://semver.org/).

## [Unreleased]

## [3.1.0] - 2026-09-22

The "make it shippable" release. Every finding of the September 2026 audit
(`AUDIT.md`) is addressed; nothing user-facing was removed.

### Added
- One-line installers: `install.sh` (Debian/Ubuntu, Fedora/RHEL, openSUSE,
  Arch, any other distro via `--user`) and `install.ps1` (Windows 11/10).
- Linux packages for **amd64 and arm64**: `.deb`, `.rpm`, AppImage and a
  relocatable `tar.gz`; all with `SHA256SUMS` and GitHub build provenance
  attestations.
- Windows: NSIS installer with bundled `clipd.exe`/`clipctl.exe`, proper
  `.ico`, real updater signing key, per-user autostart.
- Windows daemon: event-driven capture (`WM_CLIPBOARDUPDATE`), HTML / files /
  image capture, focused-app blacklist, per-user named pipe with an owner-only
  DACL.
- `security.sensitive_expiry_minutes` and `security.clear_after_paste` are now
  implemented in the daemon; secrets (API keys, private keys, card numbers,
  JWTs …) are flagged and auto-expire.
- Config changes apply live (`SaveConfig` / `ReloadConfig`); no daemon restart.
- `clipd --version`, `clipctl` parity with the protocol (`get`, bulk ops,
  snippets, regex, config).
- Tags are returned in `ClipboardItem.tags`; the UI shows and filters them.
- Full-text search now indexes item content (not just the 200-char preview),
  ignores diacritics and treats punctuation literally (`foo-bar`, `C++`).
- Frontend: ESLint, Prettier, Vitest test-suite, i18n parity check; list and
  emoji/symbol grids are virtualised; all pickers are lazy-loaded.
- Repository: `CHANGELOG.md`, `CONTRIBUTING.md`, `SECURITY.md`, `docs/`,
  `cargo-deny`, Dependabot, split CI / release workflows.

### Changed
- IPC socket moved to `$XDG_RUNTIME_DIR/linvclip/clipd.sock` (0700 directory,
  single-instance lock). Clients and daemon are upgraded together by every
  package, so no action is needed.
- `.deb` now declares real `Depends:` (computed from the binaries) and its
  maintainer scripts follow Debian Policy (no `su`, no `pkill`, no `$HOME`
  edits, no dpkg-database rewriting). `/etc/xdg/autostart/linvclipboard.desktop`
  is a conffile.
- `clipd.service` hardening fixed to match the paths the daemon actually uses;
  `MemoryMax` raised so a large image cannot OOM-kill the daemon.
- Linux in-app updates no longer generate root shell scripts. The GUI
  downloads the `.deb`/`.rpm` for the detected install kind, verifies it
  against the release's `SHA256SUMS`, and hands the file to a fixed,
  packaged helper (`/usr/libexec/linvclipboard/apply-update`) through a
  polkit action; AppImage and Windows use the signed Tauri updater. The
  weekly timer only notifies.
- Release binaries are built with thin LTO and stripped (`clipd` ~11 MB → ~4 MB).
- Node 22, SHA-pinned GitHub Actions, `Cargo.lock` committed.

### Fixed
- Windows port compiled for the first time (9 type errors, use-after-move).
- Blacklisted-app bypass on focus change (password captured after Alt-Tab).
- Daemon panic on `%`-encoded `file://` URIs with multibyte characters.
- IPC server `expect()` on clipboard init at boot (daemon alive with no socket).
- `clipctl list` panic on non-ASCII previews / short IDs.
- Config parse failure now fails **closed** (incognito) instead of silently
  resetting security settings.
- Keyboard actions acted on the unfiltered list while a filter pill was active
  (wrong item deleted / pasted).
- Vim `dd`/`gg` fired while typing in snippet/tag inputs.
- GIF tab refetch loop; dropped debounced searches; stale search results.
- Redaction bypass via `aria-label`, chip tooltips and the preview pane.
- Escape in snippet dialogs hid the whole window.
- Regex search pagination stopped after the first page.
- 10 undefined CSS variables, duplicate `.color-swatch`, dead rules.
- Weekly update-check unit hung forever (`--version` unimplemented, no timeout).
- `MemoryMax=50M` vs 50 MB `max_item_size_bytes` OOM kill.

### Removed
- Generated `pkexec bash /tmp/*.sh` updater scripts on Linux (see *Changed*).
- Dead Unix "platform abstraction" copies, duplicated Windows request handler,
  `cargo-deb` metadata, `bundle.linux.deb` config, stale `windows/resources`,
  planning documents (moved to git history / `docs/`).

## [3.0.3] - 2026-08-20
### Added
- Windows auto-update via Tauri updater plugin (configuration only; see 3.1.0).
### Fixed
- CI and updater bug fixes.

## [3.0.2] - 2026-08-12
### Fixed
- Duplicate user-level autostart entry on install (double tray icons).

## [3.0.1] - 2026-08-05
### Fixed
- Monitor survives boot-time clipboard attach failure.

## [3.0.0] - 2026-07-20
### Added
- Regex search, format converter (JSON/YAML/TOML), colour picker.
- Initial Windows port scaffolding (platform abstraction layer, named-pipe IPC).

[Unreleased]: https://github.com/DreamerX00/LinVClipBoard/compare/v3.1.0...HEAD
[3.1.0]: https://github.com/DreamerX00/LinVClipBoard/compare/v3.0.3...v3.1.0
[3.0.3]: https://github.com/DreamerX00/LinVClipBoard/compare/v3.0.2...v3.0.3
[3.0.2]: https://github.com/DreamerX00/LinVClipBoard/compare/v3.0.1...v3.0.2
[3.0.1]: https://github.com/DreamerX00/LinVClipBoard/compare/v3.0.0...v3.0.1
[3.0.0]: https://github.com/DreamerX00/LinVClipBoard/releases/tag/v3.0.0
