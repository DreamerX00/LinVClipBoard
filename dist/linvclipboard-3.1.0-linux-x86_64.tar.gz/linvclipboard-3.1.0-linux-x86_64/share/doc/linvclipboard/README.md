<p align="center">
  <img src="crates/linvclip-ui/src-tauri/icons/icon.png" width="110" alt="LinVClipBoard" />
</p>

<h1 align="center">LinVClipBoard</h1>

<p align="center">
  A keyboard-driven clipboard history manager for Linux and Windows.<br/>
  Rust daemon &bull; SQLite/FTS5 history &bull; Tauri v2 overlay &bull; CLI
</p>

<p align="center">
  <a href="https://github.com/DreamerX00/LinVClipBoard/actions/workflows/ci.yml"><img src="https://img.shields.io/github/actions/workflow/status/DreamerX00/LinVClipBoard/ci.yml?branch=main&style=flat-square&label=CI" alt="CI" /></a>
  <a href="https://github.com/DreamerX00/LinVClipBoard/releases/latest"><img src="https://img.shields.io/github/v/release/DreamerX00/LinVClipBoard?style=flat-square&label=release" alt="Latest release" /></a>
  <a href="LICENSE"><img src="https://img.shields.io/github/license/DreamerX00/LinVClipBoard?style=flat-square" alt="MIT License" /></a>
  <img src="https://img.shields.io/badge/rust-1.87%2B-orange?style=flat-square&logo=rust" alt="Rust 1.87+" />
  <img src="https://img.shields.io/badge/tauri-v2-24C8D8?style=flat-square&logo=tauri" alt="Tauri v2" />
</p>

LinVClipBoard records everything you copy - text, HTML, links, file lists and images - into a
local SQLite database, and gives it back to you through a small always-on-top overlay
(`linvclip-ui`, default shortcut **Ctrl+/**), a tray icon and a CLI (`clipctl`). A single
background daemon (`clipd`) owns the history; the GUI and the CLI are thin clients talking to it
over a local socket. Nothing leaves your machine unless you use the GIF search or the link
preview, both of which are optional.

## Screenshots

Screenshots live in [`docs/screenshots/`](docs/screenshots/). The directory currently holds a
placeholder; contributions of overlay/settings/CLI captures are welcome (PNG, dark theme, 2x).

## Features

- **Capture** plain text, HTML (with text fallback), single URLs, file lists (`text/uri-list`,
  GNOME copied-files) and images (stored as PNG blobs). Duplicates are collapsed by SHA-256 and
  bumped to the top.
- **Search**: FTS5 full-text search over the whole content (prefix matching,
  diacritic-insensitive, punctuation literal) plus regular-expression search.
- **Organise**: pin, tag, filter by type, bulk select/delete/pin.
- **Snippets** with `{{variables}}`, folders and abbreviations; five templates are seeded.
- **Pickers**: 1,870 emoji in 9 categories, Unicode symbol tables and kaomoji, GIF search
  (KLIPY, only when a key is baked in at build time), colour picker.
- **Tools**: JSON/YAML/TOML converters, syntax highlighting, QR code for any item, link
  preview cards, OCR of image items via `tesseract` (Linux, optional install).
- **Security**: focused-app blacklist, incognito mode, heuristic secret detection with early
  expiry, clear-after-paste, UI redaction of detected secrets.
- **UI**: auto/dark/light plus Catppuccin (4 variants), Nord and Dracula themes; accent colour;
  zoom 50-200%; English, Portuguese, Hindi and Japanese; optional vim keys (`j/k`, `gg`, `dd`,
  `y`, `?`); every binding is remappable.
- **Platforms**: Linux X11 and Wayland (x86_64, aarch64) and Windows 10 1809+/11 (x64).

## Install

### Linux (any glibc distribution)

```bash
curl -fsSL https://raw.githubusercontent.com/DreamerX00/LinVClipBoard/main/install.sh | bash
```

The script detects apt/dnf/zypper/pacman, downloads the matching release asset, verifies its
SHA-256 (and its build attestation when `gh` is logged in) and installs it with your package
manager so WebKitGTK and friends are resolved for you. Useful flags: `--user` (no root,
tarball into `~/.local`), `--version X.Y.Z`, `--method deb|rpm|tar|appimage`, `--dry-run`,
`--uninstall`. Full per-distro instructions: [docs/INSTALL.md](docs/INSTALL.md).

### Windows 10 (1809+) / 11

```powershell
irm https://raw.githubusercontent.com/DreamerX00/LinVClipBoard/main/install.ps1 | iex
```

Per-user NSIS install into `%LOCALAPPDATA%\LinVClipBoard`, autostart through the `HKCU` Run
key, in-app updates via the signed Tauri updater. Unsigned builds trigger a SmartScreen prompt;
see [docs/INSTALL.md](docs/INSTALL.md#windows).

### Manual downloads

Every tag on the [Releases page](https://github.com/DreamerX00/LinVClipBoard/releases) ships:

| Asset | Platform |
|---|---|
| `linvclipboard_X.Y.Z-1_{amd64,arm64}.deb` | Debian, Ubuntu, Mint, Pop!_OS |
| `linvclipboard-X.Y.Z-1.{x86_64,aarch64}.rpm` | Fedora, RHEL/Alma/Rocky 9+, openSUSE |
| `LinVClipBoard-X.Y.Z-{x86_64,aarch64}.AppImage` | Any glibc distro, no root |
| `linvclipboard-X.Y.Z-linux-{x86_64,aarch64}.tar.gz` | Arch/Manjaro, `--user` installs, custom prefixes |
| `LinVClipBoard_X.Y.Z_x64-setup.exe` (+ `.sig`, `latest.json`) | Windows x64 |
| `SHA256SUMS`, `install.sh`, `install.ps1`, rendered winget/scoop/chocolatey/AUR manifests | - |

Verify a download before installing it:

```bash
sha256sum -c SHA256SUMS --ignore-missing
gh attestation verify <file> --repo DreamerX00/LinVClipBoard
```

winget and AUR (`linvclipboard-bin`) publishing jobs exist in the release workflow and will go
live once the maintainer adds the corresponding secrets; until then the rendered manifests are
attached to each release for manual use.

## Usage

- Press **Ctrl+/** (change it in Settings) or click the tray icon to open the overlay. Type to
  search, arrows/`j`/`k` to move, **Enter** to paste, **Delete** to remove, `p` to pin,
  **Right arrow** for the preview pane, `1`-`6` for the tabs, `?`/**Ctrl+/** for the cheat sheet,
  **Escape** to hide.
- On GNOME or KDE Wayland the global shortcut cannot be registered by the app; bind
  `linvclip-ui --toggle` in your desktop's keyboard settings instead (see below).
- The tray menu lists the most recent items (`ui.tray_items`, default 5) for one-click paste.

`clipctl` gives you the same history from a terminal. IDs may be abbreviated to any unique
prefix (the 8-character form printed by `list` is enough; prefixes are resolved against the
newest 1000 items):

```bash
clipctl list --limit 10              # newest items, pinned first
clipctl search "invoice 2026"        # full-text search
clipctl regex 'AKIA[0-9A-Z]{16}'     # regex search
clipctl get 3f9a1c2e                 # full item, tags, size, source app
clipctl cat 3f9a1c2e > out.txt       # raw content for piping
clipctl paste 3f9a1c2e               # put it back on the clipboard
clipctl pin 3f9a1c2e && clipctl tag 3f9a1c2e work
clipctl config incognito on          # pause capture; `off` resumes
clipctl status --json                # daemon uptime, item count, protocol version
clipctl doctor                       # paths, session type, helper tools, daemon reachability
clipctl completions zsh > ~/.zfunc/_clipctl
```

## Configuration

`clipd` creates `~/.config/linvclip/config.toml` (Windows:
`%APPDATA%\LinVClipBoard\config.toml`) on first start and hot-reloads it when it changes. The
GUI's Settings panel writes the same file. Unknown keys are rejected, and a file that fails to
parse makes the daemon start with defaults **and incognito on** (fail closed).

| Key | Default | Notes |
|---|---|---|
| `daemon.poll_interval_ms` | `250` | Clipboard poll interval, clamped to 50-5000. Halves automatically when idle. |
| `daemon.log_level` | `"info"` | `trace`, `debug`, `info`, `warn`, `error`. `RUST_LOG` overrides. |
| `security.blacklisted_apps` | `["keepassxc", "1password", "bitwarden"]` | Case-insensitive substring match on the focused app id / process name. |
| `security.incognito` | `false` | Pause all capture. |
| `security.sensitive_expiry_minutes` | `0` | Delete items flagged as secrets after N minutes (0 = never). |
| `security.clear_after_paste` | `false` | Remove an unpinned item from history once it is pasted. |
| `storage.max_items` | `10000` | Oldest unpinned items are removed first. |
| `storage.max_item_size_bytes` | `52428800` (50 MiB) | Applies to text, HTML and images; minimum 1024. |
| `storage.expiry_days` | `30` | Unpinned items older than this are removed (0 = never). |
| `features.auto_ocr` | `false` | OCR images on capture (Linux, needs `tesseract`). |
| `features.smart_paste` | `true` | Show detected-format badges (JSON, URL, colour, ...). |
| `features.redact_sensitive` | `true` | Mask detected secrets in the UI until revealed. |
| `ui.shortcut` | `"Ctrl+/"` | Global toggle shortcut. |
| `ui.theme` | `"auto"` | `auto`, `dark`, `light`, `catppuccin-latte/-frappe/-macchiato/-mocha`, `nord`, `dracula`. |
| `ui.language` | `"en"` | `en`, `pt`, `ja`, `hi`. |
| `ui.window_position` | `"mouse"` | `mouse` or `fixed`. |
| `ui.window_width` / `ui.window_height` | `420` / `520` | Clamped to 240-4096. |
| `ui.zoom` | `100` | 50-200 percent. |
| `ui.accent_color` | `"auto"` | `auto` or a hex colour such as `#818cf8`. |
| `ui.tray_items` | `5` | Recent items in the tray menu, 3-15. |

Data lives in `~/.local/share/linvclip/` (`clipboard.db` + `blobs/`; Windows
`%LOCALAPPDATA%\LinVClipBoard`). The IPC endpoint is `$XDG_RUNTIME_DIR/linvclip/clipd.sock` on
Linux and a per-user named pipe on Windows. See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Wayland notes

- **Capture** works on every compositor: `arboard` (built with `wayland-data-control`) reads
  the clipboard through the wlr-data-control protocol on wlroots and KDE, and `wl-clipboard-rs`
  adds the HTML and file-list MIME types. On GNOME, which does not implement data-control,
  `arboard` falls back to the X11 clipboard through XWayland.
- **Focused-app blacklist** needs a way to read the active window. Backends, probed once at
  start: `swaymsg` (Sway / i3-compatible IPC, `$SWAYSOCK`), `hyprctl` (Hyprland), `xdotool`
  (X11 sessions only). GNOME and KDE Wayland expose no unprivileged focused-window API, so the
  blacklist is not enforced there; the daemon logs a warning and you should rely on your
  password manager's own "clear clipboard" setting.
- **Global shortcut**: the Tauri global-shortcut plugin has no Wayland backend on GNOME/KDE.
  Bind `linvclip-ui --toggle` to a key in Settings > Keyboard (GNOME) or System Settings >
  Shortcuts (KDE).
- **Paste-into-app** ("type" action) uses `wtype` (wlroots), `xdotool` (X11/XWayland) or
  `ydotool` when present; without them the item is simply placed on the clipboard.

## Uninstall

```bash
# Linux, any method the installer used
curl -fsSL https://raw.githubusercontent.com/DreamerX00/LinVClipBoard/main/install.sh | bash -s -- --uninstall
# or: sudo apt remove linvclipboard / sudo dnf remove linvclipboard
rm -rf ~/.config/linvclip ~/.local/share/linvclip   # optional: history and config
```

Windows: Settings > Apps > LinVClipBoard, or `install.ps1 -Uninstall`. History in
`%LOCALAPPDATA%\LinVClipBoard\data` is kept.

## Documentation

- [docs/INSTALL.md](docs/INSTALL.md) - per-distro install, `--user` mode, systemd, troubleshooting
- [docs/BUILDING.md](docs/BUILDING.md) - prerequisites, build/test/lint, packaging, releasing
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) - components, data flow, storage schema, threading
- [docs/PROTOCOL.md](docs/PROTOCOL.md) - IPC wire format and every request/response
- [CONTRIBUTING.md](CONTRIBUTING.md), [CHANGELOG.md](CHANGELOG.md), [SECURITY.md](SECURITY.md)
- Man pages: `man clipd`, `man clipctl`, `man linvclip-ui`

## License

[MIT](LICENSE). Copyright 2025-2026 LinVClipBoard Contributors.
